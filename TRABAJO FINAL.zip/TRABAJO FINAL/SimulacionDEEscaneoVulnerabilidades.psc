Algoritmo SimulacionEscaneoVulnerabilidades
	Dimension hosts[100]
	Dimension servicios[100, 10]
	Dimension intentos[100, 10]
	Dimension vulnerabilidades[100, 10]
	contadorHosts <- 0
	
	Repetir
		Escribir "=== SISTEMA DE ESCANEO DE VULNERABILIDADES ==="
		Escribir "1. Registrar Host"
		Escribir "2. Analizar Vulnerabilidades"
		Escribir "3. Mostrar Reporte"
		Escribir "4. Salir"
		Escribir "Seleccione una opcion: "
		Leer opcion
		
		Segun opcion Hacer
			1:
				RegistrarHost(hosts, contadorHosts, servicios, intentos, vulnerabilidades)
			2:
				AnalizarVulnerabilidades(hosts, contadorHosts, servicios, intentos, vulnerabilidades)
			3:
				MostrarReporte(hosts, contadorHosts, servicios, intentos, vulnerabilidades)
			4:
				Escribir "Saliendo del sistema..."
			De Otro Modo:
				Escribir "Opcion no valida"
		FinSegun
	Hasta Que opcion = 4
FinAlgoritmo

SubProceso RegistrarHost(hosts, contadorHosts Por Referencia, servicios, intentos, vulnerabilidades)
	Si contadorHosts >= 100 Entonces
		Escribir "Error: No se pueden registrar mas hosts"
		
	FinSi
	
	Escribir "Ingrese la direccion IP del host: "
	Leer ip
	hosts[contadorHosts] <- ip
	
	Escribir "Cuantos servicios tiene este host (max 10)? "
	Leer numServicios
	
	Si numServicios > 10 Entonces
		numServicios <- 10
	FinSi
	
	Para i <- 0 Hasta numServicios - 1 Hacer
		Escribir "Servicio ", i + 1, ": "
		Leer servicio
		servicios[contadorHosts, i] <- servicio
		intentos[contadorHosts, i] <- 0
		vulnerabilidades[contadorHosts, i] <- 0
	FinPara
	
	contadorHosts <- contadorHosts + 1
	Escribir "Host registrado exitosamente"
FinSubProceso

SubProceso AnalizarVulnerabilidades(hosts, contadorHosts, servicios, intentos, vulnerabilidades)
	Si contadorHosts = 0 Entonces
		Escribir "Error: No hay hosts registrados"
		
	FinSi
	
	Escribir "=== ANALISIS DE VULNERABILIDADES ==="
	Para i <- 0 Hasta contadorHosts - 1 Hacer
		Escribir "Analizando host: ", hosts[i]
		Para j <- 0 Hasta 9 Hacer
			Si servicios[i, j] <> "" Entonces
				intentos[i, j] <- intentos[i, j] + 1
				vulnerabilidad <- azar(101)
				vulnerabilidades[i, j] <- vulnerabilidad
				Escribir "  Servicio ", servicios[i, j], " - Vulnerabilidad: ", vulnerabilidad, "%"
			FinSi
		FinPara
	FinPara
	Escribir "Analisis completado"
FinSubProceso

SubProceso MostrarReporte(hosts, contadorHosts, servicios, intentos, vulnerabilidades)
	Si contadorHosts = 0 Entonces
		Escribir "Error: No hay datos para generar reporte"
		
	FinSi
	
	Escribir "=== REPORTE DE RIESGO ==="
	Escribir ""
	
	totalRiesgo <- 0
	hostsCriticos <- 0
	
	Para i <- 0 Hasta contadorHosts - 1 Hacer
		Escribir "Host: ", hosts[i]
		Escribir "Servicios:"
		maxVulnerabilidad <- 0
		serviciosActivos <- 0
		
		Para j <- 0 Hasta 9 Hacer
			Si servicios[i, j] <> "" Entonces
				serviciosActivos <- serviciosActivos + 1
				riesgo <- vulnerabilidades[i, j]
				Si riesgo > maxVulnerabilidad Entonces
					maxVulnerabilidad <- riesgo
				FinSi
				
				estado <- "BAJO"
				Si riesgo >= 80 Entonces
					estado <- "CRITICO"
				SiNo
					Si riesgo >= 60 Entonces
						estado <- "ALTO"
					SiNo
						Si riesgo >= 40 Entonces
							estado <- "MEDIO"
						FinSi
					FinSi
				FinSi
				
				Escribir "  - ", servicios[i, j], " | Intentos: ", intentos[i, j], " | Vulnerabilidad: ", riesgo, "% | Estado: ", estado
			FinSi
		FinPara
		
		nivelHost <- "BAJO"
		Si maxVulnerabilidad >= 80 Entonces
			nivelHost <- "CRITICO"
			hostsCriticos <- hostsCriticos + 1
		SiNo
			Si maxVulnerabilidad >= 60 Entonces
				nivelHost <- "ALTO"
			SiNo
				Si maxVulnerabilidad >= 40 Entonces
					nivelHost <- "MEDIO"
				FinSi
			FinSi
		FinSi
		
		totalRiesgo <- totalRiesgo + maxVulnerabilidad
		Escribir "Nivel de riesgo del host: ", nivelHost
		Escribir "----------------------------------------"
	FinPara
	
	promedioRiesgo <- totalRiesgo / contadorHosts
	Escribir "RESUMEN GENERAL:"
	Escribir "Total de hosts: ", contadorHosts
	Escribir "Hosts criticos: ", hostsCriticos
	Escribir "Nivel de riesgo promedio: ", promedioRiesgo, "%"
	
	riesgoGeneral <- "BAJO"
	Si promedioRiesgo >= 70 Entonces
		riesgoGeneral <- "ALTO"
	SiNo
		Si promedioRiesgo >= 50 Entonces
			riesgoGeneral <- "MEDIO"
		FinSi
	FinSi
	
	Escribir "Estado general del sistema: ", riesgoGeneral
FinSubProceso
