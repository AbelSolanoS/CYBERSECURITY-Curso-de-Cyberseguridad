Algoritmo SimuladorDEFirewallBasico
	Dimension bloqueadas[100]
	Dimension registros[100,4]
	Definir opcion, iBloq, iReg, encontrado, i Como Entero
	Definir ip, puerto, protocolo Como Cadena
	iBloq <- 0
	iReg <- 0
	Repetir
		Escribir "1. Agregar IP bloqueada"
		Escribir "2. Mostrar IPs bloqueadas"
		Escribir "3. Registrar paquete"
		Escribir "4. Mostrar registros"
		Escribir "5. Mostrar alertas por IP"
		Escribir "6. Salir"
		Escribir "Seleccione una opcion:"
		Leer opcion
		Segun opcion Hacer
			1:
				Si iBloq < 100 Entonces
					Escribir "Ingrese IP a bloquear:"
					Leer ip
					iBloq <- iBloq + 1
					bloqueadas[iBloq] <- ip
					Escribir "IP bloqueada correctamente."
				SiNo
					Escribir "Lista de IPs bloqueadas llena."
				FinSi
			2:
				Si iBloq = 0 Entonces
					Escribir "No hay IPs bloqueadas."
				SiNo
					Escribir "IPs bloqueadas:"
					Para i <- 1 Hasta iBloq Hacer
						Escribir i, ". ", bloqueadas[i]
					FinPara
				FinSi
			3:
				Si iReg < 100 Entonces
					Escribir "Ingrese IP origen:"
					Leer ip
					Escribir "Ingrese puerto destino:"
					Leer puerto
					Escribir "Ingrese protocolo (TCP/UDP/ICMP):"
					Leer protocolo
					encontrado <- 0
					Para i <- 1 Hasta iBloq Hacer
						Si bloqueadas[i] = ip Entonces
							encontrado <- 1
							
						FinSi
					FinPara
					iReg <- iReg + 1
					registros[iReg,1] <- ip
					registros[iReg,2] <- puerto
					registros[iReg,3] <- protocolo
					Si encontrado = 1 Entonces
						registros[iReg,4] <- "SI"
						Escribir "ALERTA: paquete proveniente de IP bloqueada"
					SiNo
						registros[iReg,4] <- "NO"
						Escribir "Paquete registrado correctamente."
					FinSi
				SiNo
					Escribir "Registro de paquetes lleno."
				FinSi
			4:
				Si iReg = 0 Entonces
					Escribir "No hay registros."
				SiNo
					Escribir "Registros de paquetes:"
					Escribir "No.  IPOrigen        Puerto  Protocolo  Alerta"
					Para i <- 1 Hasta iReg Hacer
						Escribir i, "  ", registros[i,1], "  ", registros[i,2], "  ", registros[i,3], "  ", registros[i,4]
					FinPara
				FinSi
			5:
				Si iReg = 0 Entonces
					Escribir "No hay registros para generar alertas"
				SiNo
					Escribir "Alertas por IP:"
					Para i <- 1 Hasta iReg Hacer
						Si registros[i,4] = "SI" Entonces
							Escribir "Registro ", i, ": IP ", registros[i,1], " - ALERTA"
						FinSi
					FinPara
				FinSi
			6:
				Escribir "Saliendo"
			DeOtroModo:
				Escribir "NO VALIDO"
		FinSegun
	Hasta Que opcion = 6
FinAlgoritmo

