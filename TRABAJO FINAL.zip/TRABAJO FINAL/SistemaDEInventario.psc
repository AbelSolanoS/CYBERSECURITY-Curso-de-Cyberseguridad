Algoritmo SistemaInventario
    Dimension equipos[5]
    Dimension ubicaciones[3]
    Dimension ips[5,3]
    Dimension estados[5,3]
    
    equipos[1] <- "Router1"
    equipos[2] <- "Switch1"
    equipos[3] <- "Servidor1"
    equipos[4] <- "Firewall1"
    equipos[5] <- "AP1"
    
    ubicaciones[1] <- "Piso1"
    ubicaciones[2] <- "Piso2"
    ubicaciones[3] <- "Piso3"
    
    Para i <- 1 Hasta 5 Con Paso 1 Hacer
        Para j <- 1 Hasta 3 Con Paso 1 Hacer
            ips[i,j] <- ""
            estados[i,j] <- ""
        FinPara
    FinPara
    
    RegistrarEquipo("Router1", "Piso1", "192.168.1.1", "Activo")
    RegistrarEquipo("Switch1", "Piso2", "192.168.1.2", "Activo")
    RegistrarEquipo("Servidor1", "Piso1", "192.168.1.10", "Inactivo")
    RegistrarEquipo("Firewall1", "Piso3", "192.168.1.3", "Activo")
    RegistrarEquipo("AP1", "Piso2", "192.168.1.20", "Inactivo")
    
    MostrarInventario
    GenerarAlertas
FinAlgoritmo

SubProceso RegistrarEquipo(equipo, ubicacion, ip, estado)
    Definir posEq, posUb Como Entero
    posEq <- 0
    posUb <- 0
    
    Para i <- 1 Hasta 5 Con Paso 1 Hacer
        Si equipos = equipo Entonces
            posEq <- i
        FinSi
    FinPara
    
    Para j <- 1 Hasta 3 Con Paso 1 Hacer
        Si ubicaciones = ubicacion Entonces
            posUb <- j
        FinSi
    FinPara
    
    Si posEq > 0 Y posUb > 0 Entonces
        ips <- ip
        estados <- estado
    FinSi
FinSubProceso

SubProceso MostrarInventario
    Escribir "INVENTARIO DE EQUIPOS"
    Escribir ""
    
    Para i <- 1 Hasta 5 Con Paso 1 Hacer
        Escribir "Equipo: ", equipos
        Para j <- 1 Hasta 3 Con Paso 1 Hacer
            Si ips <> "" Entonces
                Escribir "Ubicacion: ", ubicaciones, " - IP: ", ips, " - Estado: ", estados
            FinSi
        FinPara
        Escribir ""
    FinPara
FinSubProceso

SubProceso GenerarAlertas
    Escribir "ALERTAS DEL SISTEMA:"
    
    Para i <- 1 Hasta 5 Con Paso 1 Hacer
        Para j <- 1 Hasta 3 Con Paso 1 Hacer
            Si estados = "Inactivo" Entonces
                Escribir "ALERTA: ", equipos, " en ", ubicaciones " esta INACTIVO"
            FinSi
        FinPara
    FinPara
FinSubProceso