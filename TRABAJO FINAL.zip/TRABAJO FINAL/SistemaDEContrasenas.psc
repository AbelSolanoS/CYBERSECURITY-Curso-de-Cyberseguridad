Algoritmo SistemaDEContrase�as
	Dimension usr[3]
	Dimension serv[2]
	Dimension intentos[3,2]
	Dimension ip[3,2]
	Dimension estado[3,2]
	Dimension horario[3,2]
	
	usr[1] <- "ana"
	usr[2] <- "luis"
	usr[3] <- "admin"
	
	serv[1] <- "web"
	serv[2] <- "bd"
	
	Para i <- 1 Hasta 3 Con Paso 1 Hacer
		Para j <- 1 Hasta 2 Con Paso 1 Hacer
			intentos[i,j] <- 0
			ip[i,j] <- ""
			estado[i,j] <- ""
			horario[i,j] <- ""
		FinPara
	FinPara
	
	RegistroAcceso("ana", "web", "192.168.1.10", "exito", "09:00")
	RegistroAcceso("luis", "bd", "192.168.1.15", "fallo", "10:30")
	RegistroAcceso("admin", "web", "192.168.1.20", "fallo", "11:45")
	RegistroAcceso("ana", "bd", "192.168.1.10", "exito", "12:15")
	
	MostrarDatos()
	BuscarAlertas()
FinAlgoritmo

SubProceso RegistroAcceso(usuario, servidor, direccion, resultado, tiempo)
	Definir u, s Como Entero
	u <- 0
	s <- 0
	
	Para i <- 1 Hasta 3 Con Paso 1 Hacer
		Si usr= usuario Entonces
			u <- i
		FinSi
	FinPara
	
	Para j <- 1 Hasta 2 Con Paso 1 Hacer
		Si serv = servidor Entonces
			s <- j
		FinSi
	FinPara
	
	Si u > 0 Y s > 0 Entonces
		intentos <- intentos + 1
		ip <- direccion
		estado <- resultado
		horario <- tiempo
	FinSi
FinSubProceso

SubProceso MostrarDatos
	Escribir "REPORTE DE ACCESOS"
	Escribir ""
	
	Para i <- 1 Hasta 3 Con Paso 1 Hacer
		Escribir "Usuario: ", usr
		Para j <- 1 Hasta 2 Con Paso 1 Hacer
			Si intentos > 0 Entonces
				Escribir serv, " - ", intentos, " - ", ip, " - ", estado, " - ", horario
			FinSi
		FinPara
		Escribir ""
	FinPara
FinSubProceso

SubProceso BuscarAlertas
	Escribir "ALERTAS:"
	
	Para i <- 1 Hasta 3 Con Paso 1 Hacer
		Para j <- 1 Hasta 2 Con Paso 1 Hacer
			Si estado = "fallo" Y intentos > 0 Entonces
				Escribir "Intento fallido: ", usr, " en ", serv
			FinSi
		FinPara
	FinPara
FinSubProceso