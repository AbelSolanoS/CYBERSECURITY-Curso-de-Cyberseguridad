Algoritmo ControlAccesosWiFi
	Dimension dispositivos[100]
	Dimension macs[100]
	Dimension ips[100]
	Dimension conexiones[100, 10]
	contadorDispositivos <- 0
	limiteConexiones <- 3
	
	Repetir
		Escribir "=== CONTROL DE ACCESOS WiFi ==="
		Escribir "1. Registrar Dispositivo"
		Escribir "2. Validar Acceso"
		Escribir "3. Generar Alertas"
		Escribir "4. Mostrar Dispositivos"
		Escribir "5. Salir"
		Escribir "Seleccione una opcion: "
		Leer opcion
		
		Segun opcion Hacer
			1:
				RegistrarDispositivo(dispositivos, macs, ips, contadorDispositivos, conexiones)
			2:
				ValidarAcceso(dispositivos, macs, ips, contadorDispositivos, conexiones, limiteConexiones)
			3:
				GenerarAlertas(dispositivos, macs, ips, contadorDispositivos, conexiones, limiteConexiones)
			4:
				MostrarDispositivos(dispositivos, macs, ips, contadorDispositivos, conexiones)
			5:
				Escribir "Saliendo del sistema..."
			De Otro Modo:
				Escribir "Opcion no valida"
		FinSegun
	Hasta Que opcion = 5
FinAlgoritmo

SubProceso RegistrarDispositivo(dispositivos, macs, ips, contadorDispositivos Por Referencia, conexiones)
	Si contadorDispositivos >= 100 Entonces
		Escribir "Error: No se pueden registrar mas dispositivos"
		
	FinSi
	
	Escribir "Ingrese nombre del dispositivo: "
	Leer nombre
	Escribir "Ingrese direccion MAC: "
	Leer mac
	Escribir "Ingrese direccion IP: "
	Leer ip
	
	dispositivos[contadorDispositivos] <- nombre
	macs[contadorDispositivos] <- mac
	ips[contadorDispositivos] <- ip
	
	Para i <- 0 Hasta 9 Hacer
		conexiones[contadorDispositivos, i] <- ""
	FinPara
	
	contadorDispositivos <- contadorDispositivos + 1
	Escribir "Dispositivo registrado exitosamente"
FinSubProceso

SubProceso ValidarAcceso(dispositivos, macs, ips, contadorDispositivos, conexiones, limiteConexiones)
	Si contadorDispositivos = 0 Entonces
		Escribir "Error: No hay dispositivos registrados"
		
	FinSi
	
	Escribir "=== VALIDACION DE ACCESO ==="
	Escribir "Ingrese direccion MAC: "
	Leer macIngresada
	
	encontrado <- Falso
	indice <- -1
	
	Para i <- 0 Hasta contadorDispositivos - 1 Hacer
		Si macs[i] = macIngresada Entonces
			encontrado <- Verdadero
			indice <- i
			i <- contadorDispositivos
		FinSi
	FinPara
	
	Si encontrado Entonces
		conexionesActivas <- 0
		Para j <- 0 Hasta 9 Hacer
			Si conexiones[indice, j] <> "" Entonces
				conexionesActivas <- conexionesActivas + 1
			FinSi
		FinPara
		
		Si conexionesActivas >= limiteConexiones Entonces
			Escribir "ALERTA: Limite de conexiones alcanzado para ", dispositivos[indice]
			Escribir "Conexiones activas: ", conexionesActivas
			Escribir "Limite permitido: ", limiteConexiones
		SiNo
			Para j <- 0 Hasta 9 Hacer
				Si conexiones[indice, j] = "" Entonces
					conexiones[indice, j] <- "Activa"
					Escribir "Acceso concedido a ", dispositivos[indice]
					Escribir "IP: ", ips[indice]
					Escribir "Conexion establecida"
					j <- 10
				FinSi
			FinPara
		FinSi
	SiNo
		Escribir "ALERTA: Intento de acceso no autorizado"
		Escribir "MAC no registrada: ", macIngresada
	FinSi
FinSubProceso

SubProceso GenerarAlertas(dispositivos, macs, ips, contadorDispositivos, conexiones, limiteConexiones)
	Si contadorDispositivos = 0 Entonces
		Escribir "Error: No hay dispositivos registrados"
		
	FinSi
	
	Escribir "=== REPORTE DE ALERTAS ==="
	alertasGeneradas <- 0
	
	Para i <- 0 Hasta contadorDispositivos - 1 Hacer
		conexionesActivas <- 0
		Para j <- 0 Hasta 9 Hacer
			Si conexiones[i, j] <> "" Entonces
				conexionesActivas <- conexionesActivas + 1
			FinSi
		FinPara
		
		Si conexionesActivas >= limiteConexiones Entonces
			Escribir "ALERTA: ", dispositivos[i], " excede limite de conexiones"
			Escribir "   MAC: ", macs[i]
			Escribir "   IP: ", ips[i]
			Escribir "   Conexiones activas: ", conexionesActivas
			Escribir "   Limite: ", limiteConexiones
			Escribir ""
			alertasGeneradas <- alertasGeneradas + 1
		FinSi
	FinPara
	
	Si alertasGeneradas = 0 Entonces
		Escribir "No se generaron alertas"
	SiNo
		Escribir "Total de alertas generadas: ", alertasGeneradas
	FinSi
FinSubProceso

SubProceso MostrarDispositivos(dispositivos, macs, ips, contadorDispositivos, conexiones)
	Si contadorDispositivos = 0 Entonces
		Escribir "Error: No hay dispositivos registrados"
		
	FinSi
	
	Escribir "=== DISPOSITIVOS REGISTRADOS ==="
	Para i <- 0 Hasta contadorDispositivos - 1 Hacer
		conexionesActivas <- 0
		Para j <- 0 Hasta 9 Hacer
			Si conexiones[i, j] <> "" Entonces
				conexionesActivas <- conexionesActivas + 1
			FinSi
		FinPara
		
		Escribir "Dispositivo: ", dispositivos[i]
		Escribir "   MAC: ", macs[i]
		Escribir "   IP: ", ips[i]
		Escribir "   Conexiones activas: ", conexionesActivas
		Escribir ""
	FinPara
FinSubProceso